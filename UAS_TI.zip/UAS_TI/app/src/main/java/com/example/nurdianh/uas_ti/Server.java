package com.example.nurdianh.uas_ti;

public class Server {
    public static final String URL = "http://nurdian.serveo.net/Register/";
}
