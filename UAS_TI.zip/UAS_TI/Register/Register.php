<?php

include_once 'koneksi.php';

$response = array("error" => FALSE);

if (isset($_POST['username']) && isset($_POST['password'])) {
 $username = htmlspecialchars($_POST['username']);
 $password = htmlspecialchars($_POST['password']);

    $sql = $conn->query("SELECT username from tableuser WHERE username = '$username'");

    if(mysqli_num_rows($sql) > 0) {
  $response["error"] = TRUE;
        $response["message"] = "User sudah ada";
        $response["success"] = 0;

        echo json_encode($response);
    }else{
     $sql = $conn->query("INSERT INTO tableuser(username, password) VALUES('$username', '$password')");

     if($sql) {
         $response["error"] = FALSE;
         $response["message"] = "Registrasi berhasil";
         $response["success"] = 1;

   echo json_encode($response);
     } else {
      $response["error"] = TRUE;
         $response["message"] = "Register gagal";
         $response["success"] = 0;

   echo json_encode($response);
     }

    }

}
?>
